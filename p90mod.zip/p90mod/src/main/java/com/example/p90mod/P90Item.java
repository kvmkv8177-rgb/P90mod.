package com.example.p90mod;

import java.util.List;

import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class P90Item extends Item {
    public static final int MAG_SIZE = 150;        // rounds in a full magazine
    public static final int ROUNDS_PER_BOX = 50;   // one 5.7mm box = 50 rounds
    public static final float DAMAGE = 7.0f;       // 3.5 hearts
    public static final double RANGE = 64.0;
    // 3000 RPM = 50 shots/second = 2.5 shots per tick -> alternate 3 and 2 shots per tick

    public P90Item(Settings settings) {
        super(settings);
    }

    // ---- ammo stored in the item's NBT ----
    public static int getAmmo(ItemStack stack) {
        return stack.hasNbt() ? stack.getNbt().getInt("Ammo") : 0;
    }

    public static void setAmmo(ItemStack stack, int ammo) {
        stack.getOrCreateNbt().putInt("Ammo", ammo);
    }

    // ---- use: hold right-click to fire, sneak + right-click (or empty mag) to reload ----
    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (player.isSneaking() || getAmmo(stack) <= 0) {
            if (!world.isClient) {
                reload(player, stack);
            }
            return TypedActionResult.fail(stack);
        }
        player.setCurrentHand(hand);
        return TypedActionResult.consume(stack);
    }

    @Override
    public int getMaxUseTime(ItemStack stack) {
        return 72000;
    }

    @Override
    public UseAction getUseAction(ItemStack stack) {
        return UseAction.NONE;
    }

    @Override
    public void usageTick(World world, LivingEntity user, ItemStack stack, int remainingUseTicks) {
        if (world.isClient || !(user instanceof PlayerEntity player)) {
            return;
        }
        int ammo = getAmmo(stack);
        if (ammo <= 0) {
            user.stopUsingItem();
            return;
        }
        int shots = Math.min(remainingUseTicks % 2 == 0 ? 3 : 2, ammo);
        for (int i = 0; i < shots; i++) {
            fire(world, player);
        }
        setAmmo(stack, ammo - shots);

        if (remainingUseTicks % 2 == 0) {
            world.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.ENTITY_ARROW_SHOOT, SoundCategory.PLAYERS, 0.6f, 1.8f);
        }
        if (ammo - shots <= 0) {
            user.stopUsingItem();
        }
    }

    private void fire(World world, PlayerEntity player) {
        Vec3d start = player.getEyePos();
        Vec3d look = player.getRotationVec(1.0f);
        Vec3d end = start.add(look.multiply(RANGE));

        // stop the bullet at the first block in the way
        HitResult blockHit = world.raycast(new RaycastContext(start, end,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
        Vec3d stop = blockHit.getType() == HitResult.Type.MISS ? end : blockHit.getPos();

        Box box = player.getBoundingBox().stretch(look.multiply(RANGE)).expand(1.0);
        EntityHitResult hit = ProjectileUtil.raycast(player, start, stop, box,
                e -> !e.isSpectator() && e.canHit(), RANGE * RANGE);

        if (hit != null) {
            Entity target = hit.getEntity();
            target.timeUntilRegen = 0; // let every bullet land (no invulnerability frames)
            target.damage(world.getDamageSources().playerAttack(player), DAMAGE);
        }
    }

    private void reload(PlayerEntity player, ItemStack gun) {
        int ammo = getAmmo(gun);
        if (ammo + ROUNDS_PER_BOX > MAG_SIZE) {
            player.sendMessage(Text.literal("Magazine full"), true);
            return;
        }
        if (player.getAbilities().creativeMode) {
            setAmmo(gun, MAG_SIZE);
            player.sendMessage(Text.literal("Reloaded"), true);
            return;
        }
        PlayerInventory inv = player.getInventory();
        boolean loaded = false;
        while (ammo + ROUNDS_PER_BOX <= MAG_SIZE) {
            int slot = -1;
            for (int i = 0; i < inv.size(); i++) {
                if (inv.getStack(i).isOf(P90Mod.AMMO)) {
                    slot = i;
                    break;
                }
            }
            if (slot < 0) {
                break;
            }
            inv.getStack(slot).decrement(1);
            ammo += ROUNDS_PER_BOX;
            loaded = true;
        }
        if (loaded) {
            setAmmo(gun, ammo);
            player.getWorld().playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.BLOCK_PISTON_EXTEND, SoundCategory.PLAYERS, 0.5f, 1.6f);
            player.sendMessage(Text.literal("Reloaded"), true);
        } else {
            player.sendMessage(Text.literal("No 5.7mm ammo"), true);
        }
    }

    // ---- magazine bar + tooltip ----
    @Override
    public boolean isItemBarVisible(ItemStack stack) {
        return true;
    }

    @Override
    public int getItemBarStep(ItemStack stack) {
        return Math.round(13.0f * getAmmo(stack) / MAG_SIZE);
    }

    @Override
    public int getItemBarColor(ItemStack stack) {
        return 0xFFD54F;
    }

    @Override
    public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, TooltipContext context) {
        tooltip.add(Text.literal("Ammo: " + getAmmo(stack) + " / " + MAG_SIZE).formatted(Formatting.GRAY));
        tooltip.add(Text.literal("Hold right-click: fire").formatted(Formatting.DARK_GRAY));
        tooltip.add(Text.literal("Sneak + right-click: reload (5.7mm)").formatted(Formatting.DARK_GRAY));
    }

    // Fabric API hook: don't replay the "equip" animation every time the ammo count changes
    public boolean allowNbtUpdateAnimation(PlayerEntity player, Hand hand, ItemStack oldStack, ItemStack newStack) {
        return false;
    }
}
