package com.example.p90mod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class P90Mod implements ModInitializer {
    public static final String MOD_ID = "p90mod";

    public static Item AMMO;
    public static Item P90;

    @Override
    public void onInitialize() {
        AMMO = Registry.register(Registries.ITEM, new Identifier(MOD_ID, "ammo_57mm"),
                new Item(new Item.Settings().maxCount(64)));
        P90 = Registry.register(Registries.ITEM, new Identifier(MOD_ID, "p90"),
                new P90Item(new Item.Settings().maxCount(1)));

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            entries.add(P90);
            entries.add(AMMO);
        });
    }
}
